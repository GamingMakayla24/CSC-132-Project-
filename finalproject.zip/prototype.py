import sys, pygame, time, serial, os
import GUI

musicPlaying = False

calRange = 200

pygame.init()

GUI.midi_filename = 'On_Little_Cat_Feet_-_ShinkoNetCavy.mid'


GUI.root = os.path.dirname(__file__) + "\\"     # this is to help get data from image files

'''
Button sytax goes:

[[Normal, Hover, Pressed],
 [Normal, Hover, Pressed,]]
'''

GUI.btnImages = [["normal.jpg", "hover.jpg", "pressed.jpg"]]

GUI.imgbuttonCount = 0  # this counts the ID number of the button class using images

GUI.objects = []


# mixer config
freq = 44100
bitsize = -16
channels = 2
buffer = 1024
pygame.mixer.init(freq, bitsize, channels, buffer)


# window config
#ps = 60
#fpsClock = pygame.time.Clock()
width, height = 640, 640
GUI.screen = pygame.display.set_mode((width, height))
GUI.font = pygame.font.SysFont('Arial', 40)


try:
    arduino = serial.Serial("COM3",timeout=1)
except:
    print('Please check the port')


def getData():
    try:
        temp = int(((str(arduino.readline())[2:-1].split("r"))[0])[0:-1])   # complicated math, dont worry it works
    except ValueError:
        time.sleep(.001)
        temp = getData()

    print(temp)
    return temp


def calibrate():
    calVals = []
    
    for x in range(100):
        calVals.append(getData())
        
    print("-------------------CALIBRATED-------------------")

    global calAvg
    calAvg = sum(calVals) // len(calVals)


def playMusic(midi_filename):
    print("----------------------------------------------------------------")
    pygame.mixer.music.load(GUI.root+midi_filename)
    pygame.mixer.music.play()

    global musicPlaying
    musicPlaying = True


calAvg = 0

calibrate()

GUI.Button(30, 30, 600, 600, 'Calibrate', calibrate, 0)

while True:
    time.sleep(.01)
    temp = getData()
    
    if musicPlaying == False and (temp < (calAvg-calRange) or temp > (calAvg+calRange)):
        playMusic(GUI.midi_filename)

    elif musicPlaying == True and temp < (calAvg+calRange) and temp > (calAvg-calRange):
        print("_____________________STOPPED_____________________")
        pygame.mixer.music.stop()
        musicPlaying = False
    

    GUI.screen.fill((20, 20, 20))
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
            
    for GUI.object in GUI.objects:
        GUI.object.chooseProcess()
        
    pygame.display.flip()
    #fpsClock.tick(fps)
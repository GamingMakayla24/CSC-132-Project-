import pygame, os, cv2, numpy as np

class Button():
    def __init__(self, x, y, width, height, buttonText='Button', onclickFunction=None, imageButton=-1, onePress=False): # imageButton -1 will result in a text button

        if imageButton != -1:
            self.imgID = imageButton

            global btnImages
            self.normalImage = pygame.image.load(root+btnImages[self.imgID][0])
            self.hoverImage = pygame.image.load(root+btnImages[self.imgID][1])
            self.pressedImage = pygame.image.load(root+btnImages[self.imgID][2])

            print(btnImages[self.imgID][0])

        self.imageButton = imageButton
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.onclickFunction = onclickFunction
        self.onePress = onePress
        self.alreadyPressed = False


        self.fillColors = {
            'normal': '#ffffff',
            'hover': '#666666',
            'pressed': '#333333',
            }   


        self.buttonSurface = pygame.Surface((self.width, self.height))
        self.buttonRect = pygame.Rect(self.x, self.y, self.width, self.height)

        if imageButton == -1:
            self.buttonSurf = font.render(buttonText, True, (20, 20, 20))
        else:
            self.buttonSurf = pygame.transform.scale(self.normalImage, (self.width, self.height))

        objects.append(self)

    def chooseProcess(self):
        if self.imageButton == -1:
            self.txtProcess()
        else:
            self.imgProcess()


    def imgProcess(self):
        mousePos = pygame.mouse.get_pos()
        self.buttonSurf = pygame.transform.scale(self.normalImage, (self.width, self.height))
        if self.buttonRect.collidepoint(mousePos):
            self.buttonSurf = pygame.transform.scale(self.hoverImage, (self.width, self.height))
            if pygame.mouse.get_pressed(num_buttons=3)[0]:
                self.buttonSurf = pygame.transform.scale(self.pressedImage, (self.width, self.height))
                
                # very necessary
                self.buttonSurface.blit(self.buttonSurf, [      
                    self.buttonRect.width/2 - self.buttonSurf.get_rect().width/2,
                    self.buttonRect.height/2 - self.buttonSurf.get_rect().height/2
                ])
                screen.blit(self.buttonSurface, self.buttonRect)
                pygame.display.update()
                
                if self.onePress:
                    self.onclickFunction()
                elif not self.alreadyPressed:
                    self.onclickFunction()
                    self.alreadyPressed = True
            else:
                self.alreadyPressed = False

        self.buttonSurface.blit(self.buttonSurf, [
            self.buttonRect.width/2 - self.buttonSurf.get_rect().width/2,
            self.buttonRect.height/2 - self.buttonSurf.get_rect().height/2
        ])
        screen.blit(self.buttonSurface, self.buttonRect)
        

    def txtProcess(self):
        mousePos = pygame.mouse.get_pos()
        self.buttonSurface.fill(self.fillColors['normal'])

        if self.buttonRect.collidepoint(mousePos):
            self.buttonSurface.fill(self.fillColors['hover'])

            if pygame.mouse.get_pressed(num_buttons=3)[0]:
                self.buttonSurface.fill(self.fillColors['pressed'])

                
                # very necessary
                self.buttonSurface.blit(self.buttonSurf, [      
                    self.buttonRect.width/2 - self.buttonSurf.get_rect().width/2,
                    self.buttonRect.height/2 - self.buttonSurf.get_rect().height/2
                ])
                screen.blit(self.buttonSurface, self.buttonRect)
                pygame.display.update()
                
                if self.onePress:
                    self.onclickFunction()
                elif not self.alreadyPressed:
                    self.onclickFunction()
                    self.alreadyPressed = True
            else:
                self.alreadyPressed = False

        self.buttonSurface.blit(self.buttonSurf, [
            self.buttonRect.width/2 - self.buttonSurf.get_rect().width/2,
            self.buttonRect.height/2 - self.buttonSurf.get_rect().height/2
        ])
        screen.blit(self.buttonSurface, self.buttonRect)